Can you modify this code to work if SwapiSearch components are more than 3 and accordingly with their location.pathname. May be in swithcase by location.pathname ?

import React, { lazy, Suspense } from "react";
import { Menu, Container } from "semantic-ui-react";
import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
  const location = useLocation();

  const SwapiSearch = location.pathname === "/planets" ? 
  lazy(() => import('./SwapiSearchPlanets')) : 
  lazy(() => import('./SwapiSearchPeople'));


  const swapiSearchComponent = swapiSearchComponents.find(
    (component) => component.path === location.pathname
  );

  const SwapiSearch = swapiSearchComponent ? swapiSearchComponent.component : null;

  return (
    <>
      <div className="header-site"><Link to="/" /></div>
      <Menu pointing stackable inverted>
        <Container>
          <Link to="/">
            <Menu.Item name="Home" />
          </Link>
          <Link to="/people">
            <Menu.Item name="people" />
          </Link>
          <Link to="/species">
            <Menu.Item name="species" />
          </Link>
          <Link to="/planets">
            <Menu.Item name="planets" />
          </Link>
          <Link to="/starships">
            <Menu.Item name="starships" />
          </Link>
          <Link to="/vehicles">
            <Menu.Item name="vehicles" />
          </Link>
          <Menu.Item style={{padding:'0'}}>
            <Suspense fallback={<div>Loading...</div>}>
              <SwapiSearch />
            </Suspense>
          </Menu.Item>
        </Container>
      </Menu>
    </>
  );
}
